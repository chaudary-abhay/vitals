ALTER TABLE `health_profiles` MODIFY COLUMN `age` text NOT NULL;--> statement-breakpoint
ALTER TABLE `health_profiles` MODIFY COLUMN `heightCm` text NOT NULL;--> statement-breakpoint
ALTER TABLE `health_profiles` MODIFY COLUMN `weightKg` text NOT NULL;--> statement-breakpoint
ALTER TABLE `health_profiles` MODIFY COLUMN `nutritionBudget` text;--> statement-breakpoint
ALTER TABLE `lab_markers` MODIFY COLUMN `value` text NOT NULL;--> statement-breakpoint
ALTER TABLE `lab_markers` MODIFY COLUMN `referenceLow` text;--> statement-breakpoint
ALTER TABLE `lab_markers` MODIFY COLUMN `referenceHigh` text;--> statement-breakpoint
ALTER TABLE `lifestyle_assessments` MODIFY COLUMN `disciplineScore` text NOT NULL;--> statement-breakpoint
ALTER TABLE `lifestyle_assessments` MODIFY COLUMN `stressScore` text NOT NULL;--> statement-breakpoint
ALTER TABLE `lifestyle_assessments` MODIFY COLUMN `recoveryScore` text NOT NULL;--> statement-breakpoint
ALTER TABLE `lifestyle_assessments` MODIFY COLUMN `sleepHours` text NOT NULL;--> statement-breakpoint
ALTER TABLE `personal_records` MODIFY COLUMN `value` text NOT NULL;
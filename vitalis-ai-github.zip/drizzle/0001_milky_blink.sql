CREATE TABLE `health_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`consentVersion` varchar(32) NOT NULL,
	`consentedAt` timestamp NOT NULL,
	`age` int NOT NULL,
	`heightCm` decimal(5,2) NOT NULL,
	`weightKg` decimal(6,2) NOT NULL,
	`region` varchar(120),
	`allergies` json NOT NULL,
	`foodAvailability` json NOT NULL,
	`nutritionBudget` decimal(10,2),
	`budgetCurrency` varchar(8) DEFAULT 'USD',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `health_profiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `health_profiles_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `lab_markers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`marker` varchar(80) NOT NULL,
	`value` decimal(12,4) NOT NULL,
	`unit` varchar(32) NOT NULL,
	`referenceLow` decimal(12,4),
	`referenceHigh` decimal(12,4),
	`collectedAt` timestamp,
	`clinicianNotes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `lab_markers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `lifestyle_assessments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`disciplineScore` int NOT NULL,
	`stressScore` int NOT NULL,
	`recoveryScore` int NOT NULL,
	`sleepHours` decimal(4,1) NOT NULL,
	`habits` json NOT NULL,
	`constraints` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `lifestyle_assessments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `personal_records` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`movement` varchar(100) NOT NULL,
	`value` decimal(10,2) NOT NULL,
	`unit` varchar(24) NOT NULL,
	`recordedAt` timestamp NOT NULL,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `personal_records_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `plan_snapshots` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`planType` enum('workout','nutrition') NOT NULL,
	`title` varchar(160) NOT NULL,
	`content` json NOT NULL,
	`generatedBy` varchar(80) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `plan_snapshots_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `posture_scans` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`storageKey` varchar(255) NOT NULL,
	`mediaType` varchar(64) NOT NULL,
	`analysisStatus` enum('queued','complete','needs_review') NOT NULL DEFAULT 'queued',
	`findings` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `posture_scans_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `user_goals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`goal` varchar(80) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `user_goals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `user_sports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`sport` varchar(80) NOT NULL,
	`proficiency` varchar(40),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `user_sports_id` PRIMARY KEY(`id`)
);

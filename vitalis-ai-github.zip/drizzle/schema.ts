import { int, json, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const healthProfiles = mysqlTable("health_profiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  consentVersion: varchar("consentVersion", { length: 32 }).notNull(),
  consentedAt: timestamp("consentedAt").notNull(),
  age: text("age").notNull(),
  heightCm: text("heightCm").notNull(),
  weightKg: text("weightKg").notNull(),
  region: varchar("region", { length: 120 }),
  allergies: json("allergies").$type<string[]>().notNull(),
  foodAvailability: json("foodAvailability").$type<string[]>().notNull(),
  nutritionBudget: text("nutritionBudget"),
  budgetCurrency: varchar("budgetCurrency", { length: 8 }).default("USD"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const userGoals = mysqlTable("user_goals", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  goal: varchar("goal", { length: 80 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const userSports = mysqlTable("user_sports", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  sport: varchar("sport", { length: 80 }).notNull(),
  proficiency: varchar("proficiency", { length: 40 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const labMarkers = mysqlTable("lab_markers", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  marker: varchar("marker", { length: 80 }).notNull(),
  value: text("value").notNull(),
  unit: varchar("unit", { length: 32 }).notNull(),
  referenceLow: text("referenceLow"),
  referenceHigh: text("referenceHigh"),
  collectedAt: timestamp("collectedAt"),
  clinicianNotes: text("clinicianNotes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const lifestyleAssessments = mysqlTable("lifestyle_assessments", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  disciplineScore: text("disciplineScore").notNull(),
  stressScore: text("stressScore").notNull(),
  recoveryScore: text("recoveryScore").notNull(),
  sleepHours: text("sleepHours").notNull(),
  habits: json("habits").$type<string[]>().notNull(),
  constraints: text("constraints"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const personalRecords = mysqlTable("personal_records", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  movement: varchar("movement", { length: 100 }).notNull(),
  value: text("value").notNull(),
  unit: varchar("unit", { length: 24 }).notNull(),
  recordedAt: timestamp("recordedAt").notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const postureScans = mysqlTable("posture_scans", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  storageKey: varchar("storageKey", { length: 255 }).notNull(),
  mediaType: varchar("mediaType", { length: 64 }).notNull(),
  analysisStatus: mysqlEnum("analysisStatus", ["queued", "complete", "needs_review"]).default("queued").notNull(),
  findings: json("findings").$type<Record<string, unknown> | null>(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const planSnapshots = mysqlTable("plan_snapshots", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  planType: mysqlEnum("planType", ["workout", "nutrition"]).notNull(),
  title: varchar("title", { length: 160 }).notNull(),
  content: json("content").$type<Record<string, unknown>>().notNull(),
  generatedBy: varchar("generatedBy", { length: 80 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type HealthProfile = typeof healthProfiles.$inferSelect;
export type PersonalRecord = typeof personalRecords.$inferSelect;
export type LabMarker = typeof labMarkers.$inferSelect;
export type PostureScan = typeof postureScans.$inferSelect;

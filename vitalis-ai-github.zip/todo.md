# Project TODO

- [x] Establish the Vitalis visual system: graphite canvas, warm ivory type, electric lime and teal accents, subtle grid/glow texture, responsive dashboard shell, and reduced-motion support.
- [x] Implement secure Manus OAuth authentication and a consent-aware guided onboarding flow for name, age, height, weight, and core biometric context.
- [x] Add goal and sport multi-select inputs, training context, allergies, regional food availability, and nutrition budget capture.
- [x] Add secure medical intake for at least 15 blood markers with value, unit, collection date, reference range, and optional clinician notes metadata.
- [x] Add psychological and lifestyle questionnaire for discipline, stress, recovery, sleep, habits, and constraints.
- [x] Add personal record create, update, delete, and review workflows with trend-ready metadata.
- [x] Add posture-analysis intake with secure image upload to object storage and database references only; reserve MediaPipe analysis adapter boundary.
- [x] Add server-side structured workout and nutrition plan generation with guarded AI tool definitions and safety constraints.
- [x] Add reusable AI coach chat surface using the existing chat component and server-side LLM calls.
- [x] Add interactive 3D-inspired anatomy dashboard with recovery, growth, and posture signals and a clear adapter boundary for React Three Fiber / Three.js.
- [x] Add algorithmic diet-optimization service contract and Node gateway adapter for a future C++ REST/gRPC microservice.
- [x] Add database schema, helpers, protected tRPC procedures, and migrations for the health domain.
- [x] Add Vitest coverage for health-data validation, guarded coach actions, and protected persistence contracts.
- [x] Run type checks, tests, and responsive visual verification before delivery.
- [ ] Create a downloadable ZIP archive of the complete project excluding secrets, dependencies, build artifacts, and runtime logs.

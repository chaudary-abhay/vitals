export type DietOptimizerRequest = {
  calories: number;
  proteinGrams: number;
  budget: number;
  currency: string;
  region: string;
  allergies: string[];
  availableFoods: string[];
};

export type DietOptimizerResponse = {
  provider: "cpp-optimizer" | "fallback";
  meals: Array<{ name: string; calories: number; proteinGrams: number; estimatedCost: number; ingredients: string[] }>;
  totalCost: number;
  constraintsApplied: string[];
};

const OPTIMIZER_URL = process.env.DIET_OPTIMIZER_URL;

/**
 * Adapter boundary for a future C++ REST/gRPC diet optimizer. The gateway owns
 * authentication, input validation, and safe fallback behavior; the optimizer
 * only receives normalized planning inputs and returns candidate meals.
 */
export async function optimizeNutrition(input: DietOptimizerRequest): Promise<DietOptimizerResponse> {
  if (OPTIMIZER_URL) {
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 2500);
      const response = await fetch(`${OPTIMIZER_URL.replace(/\/$/, "")}/v1/optimize`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-Vitalis-Adapter": "cpp-diet-optimizer" },
        body: JSON.stringify(input),
        signal: controller.signal,
      });
      clearTimeout(timeout);
      if (response.ok) return { ...(await response.json() as Omit<DietOptimizerResponse, "provider">), provider: "cpp-optimizer" };
    } catch (error) {
      console.warn("[DietOptimizer] C++ service unavailable; using safe fallback", error);
    }
  }
  const budgetPerMeal = input.budget / 3;
  const proteinPerMeal = Math.round(input.proteinGrams / 3);
  const safeFoods = input.availableFoods.filter(food => !input.allergies.some(allergy => food.toLowerCase().includes(allergy.toLowerCase())));
  const staple = safeFoods.slice(0, 3).length ? safeFoods.slice(0, 3) : ["oats", "lentils", "seasonal greens"];
  return {
    provider: "fallback",
    meals: ["Breakfast", "Lunch", "Dinner"].map((name, index) => ({
      name,
      calories: Math.round(input.calories / 3),
      proteinGrams: proteinPerMeal,
      estimatedCost: Number(budgetPerMeal.toFixed(2)),
      ingredients: [staple[index] ?? staple[0]!, "seasonal produce", "protein anchor"],
    })),
    totalCost: Number(input.budget.toFixed(2)),
    constraintsApplied: [`Region: ${input.region}`, `Budget: ${input.currency} ${input.budget.toFixed(2)}`, `Allergies excluded: ${input.allergies.length}`],
  };
}

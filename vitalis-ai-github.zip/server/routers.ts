import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { invokeLLM } from "./_core/llm";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { deleteRecord, getHealthSnapshot, getPersonalRecords, saveGoalsAndSports, saveHealthProfile, saveLabs, saveLifestyle, savePlan, savePostureReference, saveRecord, updateRecord } from "./db";
import { optimizeNutrition } from "./services/dietOptimizer";
import { encryptSensitive } from "./crypto";

const labSchema = z.object({
  marker: z.string().min(2).max(80), value: z.number().finite(), unit: z.string().min(1).max(32),
  referenceLow: z.number().finite().optional(), referenceHigh: z.number().finite().optional(),
  collectedAt: z.coerce.date().optional(), clinicianNotes: z.string().max(1200).optional(),
});
const profileSchema = z.object({
  consentVersion: z.string().min(1).max(32), age: z.number().int().min(13).max(110),
  heightCm: z.number().positive().max(260), weightKg: z.number().positive().max(400),
  region: z.string().max(120).optional(), allergies: z.array(z.string().max(80)).max(30),
  foodAvailability: z.array(z.string().max(80)).max(50), nutritionBudget: z.number().nonnegative().max(100000).optional(),
  budgetCurrency: z.string().length(3).optional(),
});

function assertSafeCoachText(text: string) {
  const blocked = [/ignore previous instructions/i, /reveal.*secret/i, /delete.*data/i, /transfer.*money/i];
  if (blocked.some(pattern => pattern.test(text))) throw new TRPCError({ code: "BAD_REQUEST", message: "Coach request blocked by safety policy." });
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  health: router({
    snapshot: protectedProcedure.query(({ ctx }) => getHealthSnapshot(ctx.user.id)),
    saveProfile: protectedProcedure.input(profileSchema).mutation(({ ctx, input }) => saveHealthProfile(ctx.user.id, { ...input, consentedAt: new Date(), age: encryptSensitive(String(input.age)), heightCm: encryptSensitive(input.heightCm.toFixed(2)), weightKg: encryptSensitive(input.weightKg.toFixed(2)), nutritionBudget: input.nutritionBudget === undefined ? undefined : encryptSensitive(input.nutritionBudget.toFixed(2)) })),
    saveGoals: protectedProcedure.input(z.object({ goals: z.array(z.string().min(2).max(80)).max(20), sports: z.array(z.string().min(2).max(80)).max(20) })).mutation(({ ctx, input }) => saveGoalsAndSports(ctx.user.id, input.goals, input.sports)),
    saveLabs: protectedProcedure.input(z.object({ markers: z.array(labSchema).min(1).max(40) })).mutation(({ ctx, input }) => saveLabs(ctx.user.id, input.markers.map(marker => ({ ...marker, value: encryptSensitive(marker.value.toFixed(4)), referenceLow: marker.referenceLow === undefined ? undefined : encryptSensitive(marker.referenceLow.toFixed(4)), referenceHigh: marker.referenceHigh === undefined ? undefined : encryptSensitive(marker.referenceHigh.toFixed(4)), clinicianNotes: marker.clinicianNotes ? encryptSensitive(marker.clinicianNotes) : undefined })))),
    saveLifestyle: protectedProcedure.input(z.object({ disciplineScore: z.number().int().min(1).max(10), stressScore: z.number().int().min(1).max(10), recoveryScore: z.number().int().min(1).max(10), sleepHours: z.number().min(0).max(24), habits: z.array(z.string().max(80)).max(30), constraints: z.string().max(1600).optional() })).mutation(({ ctx, input }) => saveLifestyle(ctx.user.id, { disciplineScore: encryptSensitive(String(input.disciplineScore)), stressScore: encryptSensitive(String(input.stressScore)), recoveryScore: encryptSensitive(String(input.recoveryScore)), sleepHours: encryptSensitive(input.sleepHours.toFixed(1)), habits: input.habits, constraints: input.constraints ? encryptSensitive(input.constraints) : undefined })),
    records: protectedProcedure.query(({ ctx }) => getPersonalRecords(ctx.user.id)),
    addPR: protectedProcedure.input(z.object({ movement: z.string().min(2).max(100), value: z.number().positive(), unit: z.string().min(1).max(24), recordedAt: z.coerce.date(), notes: z.string().max(800).optional() })).mutation(({ ctx, input }) => saveRecord(ctx.user.id, { ...input, value: encryptSensitive(input.value.toFixed(2)) })),
    updatePR: protectedProcedure.input(z.object({ id: z.number().int().positive(), movement: z.string().min(2).max(100).optional(), value: z.number().positive().optional(), unit: z.string().min(1).max(24).optional(), recordedAt: z.coerce.date().optional(), notes: z.string().max(800).optional() })).mutation(({ ctx, input }) => { const { id, value, ...rest } = input; return updateRecord(ctx.user.id, id, { ...rest, ...(value === undefined ? {} : { value: encryptSensitive(value.toFixed(2)) }) }); }),
    deletePR: protectedProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ ctx, input }) => deleteRecord(ctx.user.id, input.id)),
    addPostureReference: protectedProcedure.input(z.object({ storageKey: z.string().min(4).max(255), mediaType: z.enum(["image/jpeg", "image/png", "image/webp"]) })).mutation(({ ctx, input }) => savePostureReference(ctx.user.id, { ...input, analysisStatus: "queued" })),
  }),
  intelligence: router({
    optimizeNutrition: protectedProcedure.input(z.object({ calories: z.number().positive(), proteinGrams: z.number().nonnegative(), budget: z.number().nonnegative(), currency: z.string().length(3), region: z.string().min(2).max(120), allergies: z.array(z.string().max(80)).max(30), availableFoods: z.array(z.string().max(80)).max(100) })).mutation(({ input }) => optimizeNutrition(input)),
    generatePlans: protectedProcedure.input(z.object({ focus: z.enum(["workout", "nutrition", "both"]) })).mutation(async ({ ctx, input }) => {
      const snapshot = await getHealthSnapshot(ctx.user.id);
      const response = await invokeLLM({
        messages: [
          { role: "system", content: "You are Vitalis, a cautious health and performance planning assistant. Use only supplied data. Never diagnose, prescribe, or invent lab interpretations. Return concise actionable JSON. Flag when clinician review is appropriate." },
          { role: "user", content: JSON.stringify({ request: input.focus, profile: snapshot.profile, goals: snapshot.goals, sports: snapshot.sports, labs: snapshot.labs, lifestyle: snapshot.lifestyle, personalRecords: snapshot.prs, posture: snapshot.posture }) },
        ],
        tools: [{ type: "function", function: { name: "propose_plan_adjustment", description: "Propose a reviewable plan change; never apply it automatically.", parameters: { type: "object", properties: { area: { type: "string", enum: ["workout", "nutrition", "recovery"] }, rationale: { type: "string" }, changes: { type: "array", items: { type: "string" } } }, required: ["area", "rationale", "changes"], additionalProperties: false } } }],
        tool_choice: "auto",
        response_format: { type: "json_schema", json_schema: { name: "vitalis_plans", strict: true, schema: { type: "object", properties: { workout: { type: "object", additionalProperties: true }, nutrition: { type: "object", additionalProperties: true }, safetyNotes: { type: "array", items: { type: "string" } } }, required: ["workout", "nutrition", "safetyNotes"], additionalProperties: false } } },
      });
      const content = response.choices?.[0]?.message?.content;
      if (typeof content !== "string") throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Plan generation returned no structured content." });
      const plans = JSON.parse(content) as { workout: Record<string, unknown>; nutrition: Record<string, unknown>; safetyNotes: string[] };
      if (input.focus !== "nutrition") await savePlan(ctx.user.id, { planType: "workout", title: "Adaptive training block", content: { ...plans.workout, safetyNotes: plans.safetyNotes }, generatedBy: "Vitalis structured coach" });
      if (input.focus !== "workout") await savePlan(ctx.user.id, { planType: "nutrition", title: "Budget-aware nutrition block", content: { ...plans.nutrition, safetyNotes: plans.safetyNotes }, generatedBy: "Vitalis structured coach" });
      return plans;
    }),
    coach: protectedProcedure.input(z.object({ message: z.string().min(1).max(2000) })).mutation(async ({ ctx, input }) => {
      assertSafeCoachText(input.message);
      const snapshot = await getHealthSnapshot(ctx.user.id);
      const response = await invokeLLM({
        messages: [
          { role: "system", content: "You are Vitalis Coach. Be warm, precise, and conservative. You may recommend logging a workout, refreshing a plan, or asking for missing data, but you cannot delete records, change prescriptions, diagnose conditions, or take external actions. If the user describes urgent symptoms, direct them to local emergency or clinical care." },
          { role: "user", content: JSON.stringify({ message: input.message, context: { profile: snapshot.profile, goals: snapshot.goals, sports: snapshot.sports, lifestyle: snapshot.lifestyle, prs: snapshot.prs } }) },
        ],
        tools: [{ type: "function", function: { name: "propose_plan_adjustment", description: "Propose a reviewable training or nutrition adjustment without applying it automatically.", parameters: { type: "object", properties: { area: { type: "string", enum: ["workout", "nutrition", "recovery"] }, rationale: { type: "string" }, changes: { type: "array", items: { type: "string" } } }, required: ["area", "rationale", "changes"], additionalProperties: false } } }],
        tool_choice: "auto",
      });
      const content = response.choices?.[0]?.message?.content;
      return typeof content === "string" ? content : content ? JSON.stringify(content) : "I’m ready to help you review your next training or recovery decision.";
    }),
  }),
});

export type AppRouter = typeof appRouter;

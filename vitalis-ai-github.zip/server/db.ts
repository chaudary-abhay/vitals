import { and, desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  healthProfiles,
  InsertUser,
  labMarkers,
  lifestyleAssessments,
  personalRecords,
  planSnapshots,
  postureScans,
  userGoals,
  users,
  userSports,
} from "../drizzle/schema";
import { ENV } from "./_core/env";
import { decryptIfEncrypted } from "./crypto";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  values.lastSignedIn = user.lastSignedIn ?? new Date();
  updateSet.lastSignedIn = values.lastSignedIn;
  if (user.role) { values.role = user.role; updateSet.role = user.role; }
  else if (user.openId === ENV.ownerOpenId) { values.role = "admin"; updateSet.role = "admin"; }
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return rows[0];
}

export async function getHealthSnapshot(userId: number) {
  const db = await getDb();
  if (!db) return { profile: undefined, goals: [], sports: [], labs: [], lifestyle: undefined, prs: [], posture: [] };
  const [profile, goals, sports, labs, lifestyle, prs, posture] = await Promise.all([
    db.select().from(healthProfiles).where(eq(healthProfiles.userId, userId)).limit(1),
    db.select().from(userGoals).where(eq(userGoals.userId, userId)),
    db.select().from(userSports).where(eq(userSports.userId, userId)),
    db.select().from(labMarkers).where(eq(labMarkers.userId, userId)).orderBy(desc(labMarkers.createdAt)),
    db.select().from(lifestyleAssessments).where(eq(lifestyleAssessments.userId, userId)).orderBy(desc(lifestyleAssessments.createdAt)).limit(1),
    db.select().from(personalRecords).where(eq(personalRecords.userId, userId)).orderBy(desc(personalRecords.recordedAt)),
    db.select().from(postureScans).where(eq(postureScans.userId, userId)).orderBy(desc(postureScans.createdAt)),
  ]);
  const profileRow = profile[0];
  const lifestyleRow = lifestyle[0];
  return {
    profile: profileRow ? { ...profileRow, age: decryptIfEncrypted(profileRow.age), heightCm: decryptIfEncrypted(profileRow.heightCm), weightKg: decryptIfEncrypted(profileRow.weightKg), nutritionBudget: decryptIfEncrypted(profileRow.nutritionBudget) } : undefined,
    goals,
    sports,
    labs: labs.map((lab) => ({ ...lab, value: decryptIfEncrypted(lab.value)!, referenceLow: decryptIfEncrypted(lab.referenceLow), referenceHigh: decryptIfEncrypted(lab.referenceHigh), clinicianNotes: decryptIfEncrypted(lab.clinicianNotes) })),
    lifestyle: lifestyleRow ? { ...lifestyleRow, disciplineScore: decryptIfEncrypted(lifestyleRow.disciplineScore)!, stressScore: decryptIfEncrypted(lifestyleRow.stressScore)!, recoveryScore: decryptIfEncrypted(lifestyleRow.recoveryScore)!, sleepHours: decryptIfEncrypted(lifestyleRow.sleepHours)!, constraints: decryptIfEncrypted(lifestyleRow.constraints) } : undefined,
    prs: prs.map((record) => ({ ...record, value: decryptIfEncrypted(record.value)! })),
    posture,
  };
}

export async function saveHealthProfile(userId: number, data: Omit<typeof healthProfiles.$inferInsert, "userId">) {
  const db = await getDb(); if (!db) return;
  await db.insert(healthProfiles).values({ ...data, userId }).onDuplicateKeyUpdate({ set: { ...data, userId } });
}

export async function saveGoalsAndSports(userId: number, goals: string[], sports: string[]) {
  const db = await getDb(); if (!db) return;
  await db.delete(userGoals).where(eq(userGoals.userId, userId));
  await db.delete(userSports).where(eq(userSports.userId, userId));
  if (goals.length) await db.insert(userGoals).values(goals.map(goal => ({ userId, goal })));
  if (sports.length) await db.insert(userSports).values(sports.map(sport => ({ userId, sport })));
}

export async function saveLabs(userId: number, markers: Array<Omit<typeof labMarkers.$inferInsert, "userId">>) {
  const db = await getDb(); if (!db || !markers.length) return;
  await db.insert(labMarkers).values(markers.map(marker => ({ ...marker, userId })));
}

export async function saveLifestyle(userId: number, data: Omit<typeof lifestyleAssessments.$inferInsert, "userId">) {
  const db = await getDb(); if (!db) return;
  await db.insert(lifestyleAssessments).values({ ...data, userId });
}

export async function getPersonalRecords(userId: number) {
  const db = await getDb(); if (!db) return [];
  return db.select().from(personalRecords).where(eq(personalRecords.userId, userId)).orderBy(desc(personalRecords.recordedAt));
}

export async function saveRecord(userId: number, data: Omit<typeof personalRecords.$inferInsert, "userId">) {
  const db = await getDb(); if (!db) return;
  await db.insert(personalRecords).values({ ...data, userId });
}

export async function updateRecord(userId: number, id: number, data: Partial<Omit<typeof personalRecords.$inferInsert, "userId" | "id" | "createdAt" | "updatedAt">>) {
  const db = await getDb(); if (!db) return;
  await db.update(personalRecords).set(data).where(and(eq(personalRecords.id, id), eq(personalRecords.userId, userId)));
}

export async function deleteRecord(userId: number, id: number) {
  const db = await getDb(); if (!db) return;
  await db.delete(personalRecords).where(and(eq(personalRecords.id, id), eq(personalRecords.userId, userId)));
}

export async function savePostureReference(userId: number, data: Omit<typeof postureScans.$inferInsert, "userId">) {
  const db = await getDb(); if (!db) return;
  await db.insert(postureScans).values({ ...data, userId });
}

export async function savePlan(userId: number, data: Omit<typeof planSnapshots.$inferInsert, "userId">) {
  const db = await getDb(); if (!db) return;
  await db.insert(planSnapshots).values({ ...data, userId });
}

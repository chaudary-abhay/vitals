import type { Express, Request, Response } from "express";
import { createContext } from "./_core/context";
import { storagePut } from "./storage";
import { savePostureReference } from "./db";

const allowed = new Set(["image/jpeg", "image/png", "image/webp"]);

export function registerPostureUploadRoutes(app: Express) {
  app.post("/api/posture/upload", async (req: Request, res: Response) => {
    try {
      const context = await createContext({ req: req as any, res: res as any, info: {} as any });
      if (!context.user) return res.status(401).json({ error: "Authentication required" });
      const mediaType = String(req.headers["content-type"] ?? "").split(";")[0];
      if (!allowed.has(mediaType)) return res.status(415).json({ error: "Use JPEG, PNG, or WebP imagery" });
      const body = req.body as Buffer;
      if (!Buffer.isBuffer(body) || body.byteLength === 0 || body.byteLength > 12 * 1024 * 1024) return res.status(413).json({ error: "Image must be between 1 byte and 12 MB" });
      const extension = mediaType === "image/png" ? "png" : mediaType === "image/webp" ? "webp" : "jpg";
      const uploaded = await storagePut(`posture/${context.user.id}/${crypto.randomUUID()}.${extension}`, body, mediaType);
      await savePostureReference(context.user.id, { storageKey: uploaded.key, mediaType, analysisStatus: "queued" });
      return res.status(201).json({ key: uploaded.key, url: uploaded.url, analysisStatus: "queued", analysisAdapter: "mediapipe-posture-v1" });
    } catch (error) {
      console.error("[PostureUpload] failed", error);
      return res.status(500).json({ error: "Unable to securely store posture imagery" });
    }
  });
}
